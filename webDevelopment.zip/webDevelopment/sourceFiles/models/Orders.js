const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({

    uemail: {
        type: String,
        required: true
    },
    prodname: {
        type: String,
        required: true
    },
    proprice: {
        type: Number,
        required: true

    },
    prodescription: {
        type: String,
        required: true

    },
    proimage: {
        type: String,
        required: true

    }
});

const Orders = mongoose.model('Orders', OrderSchema);

module.exports = Orders;