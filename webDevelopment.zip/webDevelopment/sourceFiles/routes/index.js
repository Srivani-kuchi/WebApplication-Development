const express = require('express');
const router = express.Router();
const Product = require('../models/Products');
const Cart = require('../models/cart');
const Orders = require('../models/Orders');
var cookies = require('cookie-parser');


router.use(cookies());

const { ensureAuthenticated, forwardAuthenticated } = require('../config/auth');

// Welcome Page
router.get('/', forwardAuthenticated, (req, res) => res.render('welcome'));

// Dashboard`
router.get('/dashboard', ensureAuthenticated, (req, res) => {
    const { name, email, _id } = req.user
    console.log('sa', req.cookies[_id])
    if (req.cookies[_id]) {
        mycart = req.cookies[_id]
    } else {
        mycart = {}
        mycart.totqty = 0;

    }
    console.log('mycart', mycart)
    if (name == "admin" && email == "admin@gmail.com") {
        res.redirect('/users/admin')
    } else {

        // res.render('dashboard', {
        //   user: req.user
        // })
        Product.find({}, function(err, result) {
            if (err) {
                res.send(err);
            } else {
                res.render('dashboard', { user: req.user, result: result, mycart: mycart });
            }
        })
    }

});

router.get('/dashboard/2', ensureAuthenticated, function(req, res) {
    res.render('dashboard2', { user: req.user })



})
router.get('/cartactiondelete/:id', function(req, res) {
    const { _id } = req.user

    var p = req.cookies[_id] ? req.cookies[_id] : null
    console.log('thevalueofpsent', p);


    value = []
    if (req.cookies[_id]) {
        Object.keys(req.cookies[_id].items).forEach(function(key) {
            if (key == req.params.id) {
                var deleteqty = req.cookies[_id].items[key].qty
                var deleteprice = ((req.cookies[_id].items[key].price) / deleteqty)

                req.cookies[_id].items[key].qty = 0
                req.cookies[_id].totprice -= (deleteqty * deleteprice)
                req.cookies[_id].totqty -= deleteqty


            } else {

                value.push(req.cookies[_id].items[key]);




            }



        });
        var cart = req.cookies[_id]
        res.cookie(_id, cart)


        res.render('shopping', { products: value, finalprice: req.cookies[_id].totprice, finalquantity: req.cookies[_id].totqty, mycart: cart })
    }




})


router.get('/cartreduce/:id', function(req, res) {
    const { _id } = req.user
    value = []
    if (req.cookies[_id]) {
        Object.keys(req.cookies[_id].items).forEach(function(key) {
            if (key == req.params.id) {
                var deleteqty = req.cookies[_id].items[key].qty
                var deleteprice = (req.cookies[_id].items[key].price) / deleteqty
                req.cookies[_id].items[key].qty -= 1;
                req.cookies[_id].items[key].price -= deleteprice;



                req.cookies[_id].totprice -= deleteprice
                req.cookies[_id].totqty -= 1
                value.push(req.cookies[_id].items[key])


            } else {

                value.push(req.cookies[_id].items[key]);




            }



        });
        var cart = req.cookies[_id]
        res.cookie(_id, cart)



        res.render('shopping', { products: value, finalprice: req.cookies[_id].totprice, finalquantity: req.cookies[_id].totqty, mycart: cart })
    }







})

router.get('/cartadd/:id', function(req, res) {
    const { _id } = req.user
    value = []
    if (req.cookies[_id]) {
        Object.keys(req.cookies[_id].items).forEach(function(key) {
            if (key == req.params.id) {
                var deleteqty = req.cookies[_id].items[key].qty
                var deleteprice = (req.cookies[_id].items[key].price) / deleteqty
                req.cookies[_id].items[key].qty = req.cookies[_id].items[key].qty + 1;
                req.cookies[_id].items[key].price = req.cookies[_id].items[key].price + deleteprice;



                req.cookies[_id].totprice += deleteprice
                req.cookies[_id].totqty += 1
                value.push(req.cookies[_id].items[key])


            } else {

                value.push(req.cookies[_id].items[key]);




            }



        });
        var cart = req.cookies[_id]
        res.cookie(_id, cart)



        res.render('shopping', { products: value, finalprice: req.cookies[_id].totprice, finalquantity: req.cookies[_id].totqty, mycart: cart })
    }







})
router.get('/add/:id', function(req, res) {
    var proid = req.params.id;
    const { name, email, _id } = req.user
    mycart = req.cookies[_id];
    var cart = new Cart(mycart ? mycart : {});
    Product.findById(proid, function(err, pro) {
        if (err) {
            return res.redirect('/');
        }
        cart.addition(pro, proid)
        mycart = cart;
        res.cookie(_id, mycart)
        console.log('after add', mycart)
        res.redirect('/dashboard')
    })
})

router.get('/shopcart', function(req, res) {
    const { _id } = req.user

    var p = req.cookies[_id] ? req.cookies[_id] : null
    console.log('thevalueofpsent', p);


    value = []
    if (p) {
        Object.keys(p.items).forEach(function(key) {
            if (p.items[key].qty != 0) {
                value.push(p.items[key]);
            }

        });
        res.render('shopping', { products: value, finalprice: p.totprice, finalquantity: p.totqty })
    } else {
        res.render('shopping', { products: value, finalprice: 0, finalquantity: 0 })

    }


    // if (!req.session.cart) {
    //     return res.render('shopping', { products: null })
    // }



})
router.get('/search', function(req, res) {




    var word = req.query.search;
    console.log(word);

    var gen = (req.query.fil);
    if (gen == 'all') {


        Product.find({ name: { $regex: ".*" + word + ".*", $options: "i" } }, function(err, pro) {
            if (err) throw err;
            res.render('dashboard', { result: pro, user: req.user });
        });
    } else if (gen == '101') {
        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $gt: 100 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('dashboard', { result: pro, user: req.user });
        });

    } else if (gen == '50') {
        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $lt: 50, $gt: 25 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('dashboard', { result: pro, user: req.user });
        });
    } else if (gen == '25') {
        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $lt: 26, $gt: -1 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('dashboard', { result: pro, user: req.user });
        });
    } else {


        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $lt: 101, $gt: 50 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('dashboard', { result: pro, user: req.user });
        });

    }




});

router.get('/adminsearch', function(req, res) {




    var word = req.query.search;
    console.log(word);

    var gen = (req.query.fil);
    if (gen == 'all') {


        Product.find({ name: { $regex: ".*" + word + ".*", $options: "i" } }, function(err, pro) {
            if (err) throw err;
            res.render('admin', { result: pro });
        });
    } else if (gen == '101') {
        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $gt: 100 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('admin', { result: pro });
        });

    } else if (gen == '50') {
        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $lt: 50, $gt: 25 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('admin', { result: pro });
        });
    } else if (gen == '25') {
        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $lt: 26, $gt: -1 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('admin', { result: pro });
        });
    } else {


        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $lt: 101, $gt: 50 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('admin', { result: pro });
        });

    }




});

router.get('/finalcheck', function(req, res) {
    const { name, email, _id } = req.user
    var p = req.cookies[_id] ? req.cookies[_id] : null
    value = []
    if (p) {
        Object.keys(p.items).forEach(function(key) {
            if (p.items[key].qty != 0) {
                value.push(p.items[key].item);
            }

        });
    }
    res.clearCookie(_id);
    for (var i = 0; i < value.length; i++) {
        var prodname = value[i].name
        var proprice = value[i].price
        var prodescription = value[i].description
        var proimage = value[i].image
        var uemail = email
        const newOrder = new Orders({
            uemail,
            prodname,
            proprice,
            prodescription,
            proimage

        });
        newOrder
            .save()
            .then(user => {

                console.log(prodname, proprice, prodescription, proimage, uemail)



            })
    }

    res.render('checkout');



})

router.get('/ordernumber', function(req, res) {
    const { name, email, _id } = req.user
    Orders.find({ uemail: email }, function(err, video) {
        if (err) throw err;
        console.log(video)
        res.render('orders', { video: video, name: name });
    });



})


////adding pagination here






module.exports = router;