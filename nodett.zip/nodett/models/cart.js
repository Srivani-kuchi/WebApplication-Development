module.exports = function Cart(oldcart) {



    this.items = oldcart.items || {};
    this.totqty = oldcart.totqty || 0;
    this.totprice = oldcart.totprice || 0;

    this.addition = function(item, id) {
        console.log('inside  add cartfunction    ')
        var stoitem = this.items[id];
        if (!stoitem) {

            stoitem = this.items[id] = { item: item, qty: 0, price: 0 }
        }

        stoitem.qty++;
        stoitem.price = stoitem.item.price * stoitem.qty;
        this.totqty++;
        this.totprice += stoitem.item.price;




    };
    this.givecart = function() {
        var cartval = [];
        for (var id in this.items) {
            cartval.push(this.items[id]);
        }

        return cartval;




    };



};