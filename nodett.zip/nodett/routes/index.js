const express = require('express');
const router = express.Router();
const Product = require('../models/Products');
const Cart = require('../models/cart');
var cookies = require('cookie-parser');


router.use(cookies());

const { ensureAuthenticated, forwardAuthenticated } = require('../config/auth');

// Welcome Page
router.get('/', forwardAuthenticated, (req, res) => res.render('welcome'));

// Dashboard`
router.get('/dashboard', ensureAuthenticated, (req, res) => {
    const { name, email, _id } = req.user
    console.log('sa', req.cookies[_id])
    if (req.cookies[_id]) {
        mycart = req.cookies[_id]
    } else {
        mycart = {}
        mycart.totqty = 0;

    }
    console.log('mycart', mycart)
    if (name == "admin" && email == "admin@gmail.com") {
        res.redirect('/users/admin')
    } else {

        // res.render('dashboard', {
        //   user: req.user
        // })
        Product.find({}, function(err, result) {
            if (err) {
                res.send(err);
            } else {
                res.render('dashboard', { user: req.user, result: result, mycart: mycart });
            }
        })
    }

});

router.get('/add/:id', function(req, res) {
    var proid = req.params.id;
    const { name, email, _id } = req.user
    mycart = req.cookies[_id];
    var cart = new Cart(mycart ? mycart : {});
    Product.findById(proid, function(err, pro) {
        if (err) {
            return res.redirect('/');
        }
        cart.addition(pro, proid)
        mycart = cart;
        res.cookie(_id, mycart)
        console.log('after add', mycart)
        res.redirect('/dashboard')
    })
})

router.get('/shopcart', function(req, res) {
    const { _id } = req.user

    var p = req.cookies[_id] ? req.cookies[_id] : null
    console.log('thevalueofpsent', p);


    value = []
    if (p) {
        Object.keys(p.items).forEach(function(key) {
            value.push(p.items[key]);

        });
        res.render('shopping', { products: value, finalprice: p.totprice, finalquantity: p.totqty })
    } else {
        res.render('shopping', { products: value, finalprice: 0, finalquantity: 0 })

    }


    // if (!req.session.cart) {
    //     return res.render('shopping', { products: null })
    // }



})
router.get('/search', function(req, res) {




    var word = req.query.search;
    console.log(word);

    var gen = (req.query.fil);
    if (gen == 'all') {


        Product.find({ name: { $regex: ".*" + word + ".*", $options: "i" } }, function(err, pro) {
            if (err) throw err;
            res.render('dashboard', { result: pro, user: req.user });
        });
    } else if (gen == '101') {
        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $gt: 100 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('dashboard', { result: pro, user: req.user });
        });

    } else if (gen == '50') {
        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $lt: 50, $gt: 25 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('dashboard', { result: pro, user: req.user });
        });
    } else if (gen == '25') {
        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $lt: 26, $gt: -1 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('dashboard', { result: pro, user: req.user });
        });
    } else {


        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $lt: 101, $gt: 50 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('dashboard', { result: pro, user: req.user });
        });

    }




});

router.get('/adminsearch', function(req, res) {




    var word = req.query.search;
    console.log(word);

    var gen = (req.query.fil);
    if (gen == 'all') {


        Product.find({ name: { $regex: ".*" + word + ".*", $options: "i" } }, function(err, pro) {
            if (err) throw err;
            res.render('admin', { result: pro });
        });
    } else if (gen == '101') {
        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $gt: 100 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('admin', { result: pro });
        });

    } else if (gen == '50') {
        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $lt: 50, $gt: 25 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('admin', { result: pro });
        });
    } else if (gen == '25') {
        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $lt: 26, $gt: -1 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('admin', { result: pro });
        });
    } else {


        Product.find({ $and: [{ name: { $regex: ".*" + word + ".*", $options: "i" } }, { price: { $lt: 101, $gt: 50 } }] }, function(err, pro) {
            if (err) throw err;
            res.render('admin', { result: pro });
        });

    }




});

module.exports = router;