const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const passport = require('passport');
const multer = require('multer');

//var csrf = require('csurf');
//var csrfprotection = csrf();
var storage = multer.diskStorage({
    destination: '/Users/madhurinimmala/Desktop/nodett/public' + '/images',
    filename: function(req, file, callback) {
        callback(null, file.originalname);
    }
});
const upload = multer({ storage: storage });
//router.use(csrfprotection)

// Load User model
const User = require('../models/User');
const Product = require('../models/Products');
const { forwardAuthenticated, ensureAuthenticated } = require('../config/auth');

// Login Page
router.get('/login', forwardAuthenticated, (req, res) => res.render('login'));

// Register Page
router.get('/register', forwardAuthenticated, (req, res) => res.render('register'));

// Register
router.post('/register', (req, res) => {
    const { name, email, password, password2 } = req.body;
    let errors = [];

    if (!name || !email || !password || !password2) {
        errors.push({ msg: 'Please enter all fields' });
    }

    if (password != password2) {
        errors.push({ msg: 'Passwords do not match' });
    }

    if (password.length < 6) {
        errors.push({ msg: 'Password must be at least 6 characters' });
    }

    if (errors.length > 0) {
        res.render('register', {
            errors,
            name,
            email,
            password,
            password2
        });
    } else {
        User.findOne({ email: email }).then(user => {
            if (user) {
                errors.push({ msg: 'Email already exists' });
                res.render('register', {
                    errors,
                    name,
                    email,
                    password,
                    password2
                });
            } else {
                const newUser = new User({
                    name,
                    email,
                    password
                });

                bcrypt.genSalt(10, (err, salt) => {
                    bcrypt.hash(newUser.password, salt, (err, hash) => {
                        if (err) throw err;
                        newUser.password = hash;
                        newUser
                            .save()
                            .then(user => {
                                req.flash(
                                    'success_msg',
                                    'You are now registered and can log in'
                                );
                                res.redirect('/users/login');
                            })
                            .catch(err => console.log(err));
                    });
                });
            }
        });
    }
});

// Login
router.post('/login', (req, res, next) => {
    passport.authenticate('local', {
        successRedirect: '/dashboard',
        failureRedirect: '/users/login',
        failureFlash: true
    })(req, res, next);
});

// Logout
router.get('/logout', ensureAuthenticated, (req, res) => {


    req.logout();
    req.flash('success_msg', 'You are logged out');

    res.redirect('/users/login');
});

router.get('/admin', (req, res) => {


    Product.find({}, function(err, result) {
        if (err) {
            res.send(err);
        } else {
            res.render('admin', { result: result });
        }
    });





})


router.get('/edit/:id', (req, res) => {
    Product.findOne({ _id: req.params.id }, function(err, result) {
        if (err) throw err;
        res.render('show', { result: result });
    });


})
router.post('/editdata/:id', function(req, res) {


    Product.update({
        _id: req.params.id
    }, {
        $set: {
            name: req.body.name,
            price: req.body.price,
            image: req.body.image,

            description: req.body.description
        }
    }, function(err, result) {
        if (err) throw err;
        res.redirect('/users/admin');
    });
});

router.get('/insert', function(req, res) {
    res.render('new');


})
router.get('/view/:id', function(req, res) {
    const { name, email, _id } = req.user
    Product.findOne({ _id: req.params.id }, function(err, result) {
        if (err) throw err;
        mycart = req.cookies[_id];
        res.render('viewitem', { result: result, mycart: mycart });
    });




})

router.post('/insertdata', function(req, res) {
    const { name, price, image, description, variety } = req.body;
    const flag = 0;

    const newProduct = new Product({
        name,
        price,
        image,
        description,
        variety,
        flag

    });
    newProduct.save()
        .then(product => {
            res.redirect('/users/admin')
        })



})
router.get('/delete/:id', (req, res) => {
    Product.update({
        _id: req.params.id
    }, {
        $set: {
            flag: 1
        }
    }, function(err, result) {
        if (err) throw err;
        res.redirect('/users/admin');
    });
});


router.post('/upload', upload.single('photo'), (req, res) => {
    if (req.file) {
        console.log(req.file)
        res.send('upload successful')
    } else throw 'error';
});




module.exports = router;